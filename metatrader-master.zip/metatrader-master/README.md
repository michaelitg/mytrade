# Trading Tools

This repository contains essentially backups of my personal trading tools used in my daily trading, and whilst is not intended to be generic tools or to provide a public trading strategy feel free to take whatever you want from this repository

The name "metatrader" is a little misnomer, initially it was only MT4 I used, but I have now added tools I use in cTrader for trading news releases (tighter spreads) and Multicharts for trading futures.

# "Robots"

Note there are no trading robots in this repository, the so called "experts" are simply tools I use to assist with execution, they do automatic position sizing and place actual market orders but do not make decisions to trade without human intervention.


