Python NewsDownlaoder V1.41

Changes:
#Version 1.41
# - Fixed small error with leap year
#Version 1.4
# - Fixed bug with wrong year in first week of next year
# - fixed error when all arguments are not given
# - added option for high impact news only
#Version 1.3
# - Added the option for future Weeks
#Version 1.2
# - Fixed bug when no news data on a particular day
#Version 1.1
# - Updated to include previous years
#Version 1.0

There are two ways you can use this script.
1. By using the python source code and downloading python to directly run the script
1.1 You can also use a BAT file to automatically run the python code after yoiu have installed python. 
2. Use the already compiled EXE file but may only work on some machines and not others



Method 1:
There are plenty of guides out there so to save time I am just going to forward to this installation guide: http://www.howtogeek.com/197947/how-...on-on-windows/
This is for windows users as this is what I am currently using. So if you are using a mac or other OS, it’s still compatible but the installation might be a bit different.

Once python is installed and the system variables are set properly we want to open up command prompt. The sys variables will enable you to run python from command line. Go to start and search for "cmd" or "command prompt" and open it up.
Once it is open type the following:

python -m pip install beautifulsoup4

This will install the module used in my code to parse the html calendar into a readable format for processing.
Everything should now be setup needed to run my code.

USAGE:
-w <number> : the number of weeks you would like to go back from current week
-f <number> : the number of weeks you would like to go forward from current week
-o <outputfile> : output the results to the filename you specify
-I : will give you high impact news only

To run scripts in python all you need to do is type "python <path to python file>" in command prompt. So in command prompt move to the working directory(cd <directory path>) where the python script is stored. My script takes in arguments so you will need to run my script via the cmd line as below:

python PythonNewsDownlaoder.py -w <number of previous weeks to include in file> -f <number of future weeks to include in file> -o <outputfile name>

The number after -w represents how many weeks you want to go back. These will be put into the archive file.
The number after -f represents how many weeks you want after the current week. These will be put into the archive file also.
the string after -o is the name you want to output the file. The script will create(and overwrite) two files. One file is the current week only, the second file(archive file) is the file that includes the previous week(s) and also the current week. If the number after -w is 0 then both files will be the same.
If you include "-I" as an argument it will include only high impact news in the output file
It may take 10-20 seconds to process all the data. This depends how may weeks you want to go back.

Example
python PythonNewsDownlaoder.py -w 2 -f 4 -o news
this will output the current weeks events in news.csv and will also output news_archive.csv which includes the previous 2 weeks, the current week and 4 weeks after.

python PythonNewsDownlaoder.py - I -w 0 -f 5 -o news
this will output only high impact news in news.csv (current week only) and news_archive.csv for this week and five weeks after.

python PythonNewsDownlaoder.py
This will run the default parameters ie, the same as "python PythonNewsDownlaoder.py -w 2 -f 1 -o news"

python is open source so you can modify the code as you see fit (you will need notepad++ to change the py file). However, if you find any bugs and don't know how to fix it, let me know and i will have a look. I am constantly modifying and updating the code for my own purposes as well.

Send me a PM (exidez) if there is anything troubling you in the install process or running the script. I am happy to help



Method 2:
Running the exe may not run on every machine. This is because the exe contains the python interpreter and the system files needed for my machine only. Hence the EXE will only work on windows 7 and windows 10.
Using the exe is very similar to the above. Just double click the exe to execute the default parameters "-w 2 -f 1 -o news".
Or you can use command prompt to change the arguments.

Example
PythonNewsDownlaoder.exe -w 2 -f 4 -o news
this will output the current weeks events in news.csv and will also output news_archive.csv which includes the previous 2 weeks, the current week and 4 weeks after.

PythonNewsDownlaoder.exe - I -w 0 -f 5 -o news
this will output only high impact news in news.csv (current week only) and news_archive.csv for this week and five weeks after.

